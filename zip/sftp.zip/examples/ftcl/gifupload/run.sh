#!/bin/sh
java -jar ../../../lib/sftp.jar -f gifupload.txt
