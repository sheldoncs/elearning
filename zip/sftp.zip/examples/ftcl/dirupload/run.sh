#!/bin/sh
java -jar ../../../lib/sftp.jar -f dirupload.txt
