Download code:::
1. Download DOM4J from www.dom4j.org
2. Modify DOM4J_CLASSPATH.bat to point to your DOM4J installation directory
 Thats it...
compile and run the sample examples.